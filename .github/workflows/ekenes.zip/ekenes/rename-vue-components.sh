#!/bin/bash

COMPONENTS_DIR="resources/js/components"

echo "🔍 Проверка и переименование файлов в $COMPONENTS_DIR..."

cd "$COMPONENTS_DIR" || exit

for file in *.vue; do
    lowercase_file=$(echo "$file" | sed -E 's/^(.)/\L\1/')
    if [ "$file" != "$lowercase_file" ]; then
        echo "📛 $file → $lowercase_file"
        mv "$file" "$lowercase_file"
    fi
done

echo "✅ Все файлы приведены к нижнему регистру."
