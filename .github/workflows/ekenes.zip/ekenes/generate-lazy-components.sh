# Папка с Vue-компонентами
BASE_DIR="resources/js"
OUTPUT_FILE="$BASE_DIR/lazy-components.js"

echo "// Автоматически сгенерировано $(date)" > "$OUTPUT_FILE"
echo "import { defineAsyncComponent } from 'vue'" >> "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

echo "Генерация lazy-компонентов в $OUTPUT_FILE..."

find "$BASE_DIR" -name "*.vue" | while read file; do
    if ! grep -qi "defineAsyncComponent" "$file"; then
        relative_path="${file#resources/js/}"
        import_path="${relative_path%.vue}"
        component_name=$(basename "$import_path")

        echo "const ${component_name^} = defineAsyncComponent(() => import('./$import_path.vue'))" >> "$OUTPUT_FILE"
    fi
done

echo "" >> "$OUTPUT_FILE"
echo "export {" >> "$OUTPUT_FILE"

# Собираем все компоненты в экспорт
find "$BASE_DIR" -name "*.vue" | while read file; do
    if ! grep -qi "defineAsyncComponent" "$file"; then
        component_name=$(basename "${file%.vue}")
        echo "  ${component_name^}," >> "$OUTPUT_FILE"
    fi
done

echo "}" >> "$OUTPUT_FILE"

echo "Готово. Lazy компоненты записаны в $OUTPUT_FILE"
