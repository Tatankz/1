#!/bin/bash

echo "🔍 Автозамена Vue импортов на строчные имена..."

# Папка с исходниками .vue, .js, .blade.php и др.
SRC_DIR="./resources"

# Примеры старых имён компонентов и новых
declare -A COMPONENTS=(
  ["Navbar"]="navbar"
  ["RequestCard"]="requestcard"
  ["ExpertCard"]="expertcard"
  ["ExampleComponent"]="examplecomponent"
)

for file in $(grep -rl --include=\*.{vue,js,blade.php} "from './components" $SRC_DIR); do
  for OLD in "${!COMPONENTS[@]}"; do
    NEW=${COMPONENTS[$OLD]}
    sed -i "s|from './components/$OLD'|from './components/$NEW'|g" "$file"
    sed -i "s|from \"./components/$OLD\"|from \"./components/$NEW\"|g" "$file"
  done
done

echo "✅ Импорты компонентов обновлены."
