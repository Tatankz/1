<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Spatie\Permission\Models\Role;

class SuperAdminSeeder extends Seeder {
    public function run(): void {
        $role = Role::firstOrCreate(['name' => 'superadmin']);
        $user = User::firstOrCreate(
            ['email' => 'superadmin@ekenes.kz'],
            ['name' => 'SuperAdmin', 'password' => bcrypt('password')]
        );
        $user->assignRole($role);

        if (!\DB::table('currencies')->where('code', 'KZT')->exists()) {
            \DB::table('currencies')->insert([
                ['code' => 'KZT', 'enabled' => true, 'is_default' => true, 'name' => 'Тенге', 'symbol' => '₸'],
                ['code' => 'RUB', 'enabled' => false, 'is_default' => false, 'name' => 'Рубль', 'symbol' => '₽'],
                ['code' => 'USD', 'enabled' => false, 'is_default' => false, 'name' => 'Доллар США', 'symbol' => '$'],
            ]);
        }
    }
}
