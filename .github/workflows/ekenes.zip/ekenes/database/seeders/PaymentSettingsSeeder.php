<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\PaymentSetting;

class PaymentSettingsSeeder extends Seeder
{
    public function run(): void
    {
        PaymentSetting::updateOrCreate(['name' => 'robokassa_login'], ['value' => 'demo']);
        PaymentSetting::updateOrCreate(['name' => 'robokassa_password1'], ['value' => 'demo_pass1']);
        PaymentSetting::updateOrCreate(['name' => 'robokassa_password2'], ['value' => 'demo_pass2']);
        PaymentSetting::updateOrCreate(['name' => 'robokassa_test'], ['value' => 'true']);
        PaymentSetting::updateOrCreate(['name' => 'cloudpayments_public'], ['value' => 'pk_test']);
        PaymentSetting::updateOrCreate(['name' => 'cloudpayments_secret'], ['value' => 'sk_test']);
        PaymentSetting::updateOrCreate(['name' => 'mobizon_api_key'], ['value' => 'kzb4...']);
    }
}
