<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Вызов сидеров
        $this->call([
            \Database\Seeders\CurrencySeeder::class,
            \Database\Seeders\RolesSeeder::class,
            // Добавляй сюда другие сидеры
        ]);
    }
}
