<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Page;

class PagesSeeder extends Seeder
{
    public function run(): void
    {
        Page::updateOrCreate(['slug' => 'contacts'], [
            'title' => 'Контакты',
            'content' => '<p>Телефон: <strong>+7 707 403 55 88</strong><br>Оператор платформы: <strong>ТОО "Isource"</strong></p>',
        ]);

        Page::updateOrCreate(['slug' => 'about'], [
            'title' => 'О проекте',
            'content' => '<p><strong>eKenes.kz</strong> — цифровая платформа для поиска экспертов и фрилансеров в Казахстане.</p>',
        ]);

        Page::updateOrCreate(['slug' => 'conditions'], [
            'title' => 'Условия предоставления услуг',
            'content' => '<p>Условия использования платформы eKenes.kz...</p>',
        ]);

        Page::updateOrCreate(['slug' => 'refund'], [
            'title' => 'Возврат и отказ от услуг',
            'content' => '<p>Пользователь может отменить заказ до начала работ...</p>',
        ]);
    }
}
