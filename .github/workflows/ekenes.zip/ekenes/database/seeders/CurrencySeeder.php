<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CurrencySeeder extends Seeder
{
    public function run(): void
    {
        DB::table('currencies')->updateOrInsert(['code' => 'KZT'], [
            'enabled' => 1,
            'is_default' => 1,
            'name' => 'Тенге',
            'symbol' => '₸',
        ]);

        DB::table('currencies')->updateOrInsert(['code' => 'RUB'], [
            'enabled' => 0,
            'is_default' => 0,
            'name' => 'Рубль',
            'symbol' => '₽',
        ]);

        DB::table('currencies')->updateOrInsert(['code' => 'USD'], [
            'enabled' => 0,
            'is_default' => 0,
            'name' => 'Доллар США',
            'symbol' => '$',
        ]);
    }
}
