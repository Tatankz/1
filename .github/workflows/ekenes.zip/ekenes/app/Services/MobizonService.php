<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class MobizonService
{
    public function sendSms(string $to, string $text)
    {
        $apiKey = env('MOBIZON_API_KEY');
        $response = Http::asForm()->post('https://api.mobizon.kz/service/message/sendSmsMessage?output=json', [
            'apiKey' => $apiKey,
            'recipient' => $to,
            'text' => $text,
        ]);

        return $response->json();
    }
}
