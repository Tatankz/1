<?php

namespace App\Livewire;

use App\Models\Currency;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class PriceDisplay extends Component
{
    public float $amount; // в тенге

    public function render()
    {
        $user = Auth::user();
        $code = $user->currency_code ?? 'KZT';

        $currency = Currency::where('code', $code)->first();

        $rate = $currency?->exchange_rate ?? 1.0;
        $symbol = $currency?->symbol ?? '₸';

        $converted = round($this->amount / $rate, 2);

        return view('livewire.price-display', [
            'converted' => $converted,
            'symbol' => $symbol,
        ]);
    }
}
