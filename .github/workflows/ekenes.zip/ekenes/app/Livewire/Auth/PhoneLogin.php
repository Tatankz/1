<?php

namespace App\Livewire\Auth;

use Livewire\Component;

class PhoneLogin extends Component
{
    public $phone = '';

    public function submit()
    {
        $this->validate([
            'phone' => ['required', 'regex:/^\+7\d{10}$/'],
        ]);

        session()->flash('success', 'Код отправлен на номер ' . $this->phone);
    }

    public function render()
    {
        return view('livewire.auth.phone-login');
    }
}
