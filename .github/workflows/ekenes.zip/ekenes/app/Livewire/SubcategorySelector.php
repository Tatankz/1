<?php

namespace App\Livewire;

use Livewire\Component;

class SubcategorySelector extends Component
{
    public function render()
    {
        return view('livewire.subcategory-selector');
    }
}
