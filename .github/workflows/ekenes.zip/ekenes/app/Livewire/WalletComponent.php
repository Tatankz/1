<?php

namespace App\Livewire;

use Livewire\Component;

class WalletComponent extends Component
{
    public function render()
    {
        return view('livewire.wallet-component');
    }
}
