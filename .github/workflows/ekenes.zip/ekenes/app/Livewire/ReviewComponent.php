<?php

namespace App\Livewire;

use Livewire\Component;

class ReviewComponent extends Component
{
    public function render()
    {
        return view('livewire.review-component');
    }
}
