<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class SettingsComponent extends Component
{
    public function render()
    {
        return view('livewire.admin.settings-component');
    }
}
