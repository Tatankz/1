<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PaymentSettingResource\Pages;
use App\Models\PaymentSetting;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class PaymentSettingResource extends Resource
{
    protected static ?string $model = PaymentSetting::class;
    protected static ?string $navigationIcon = 'heroicon-o-key';
    protected static ?string $navigationGroup = 'Настройки';
    protected static ?string $label = 'API-ключи';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('name')
                ->label('Параметр')
                ->disabled(),

            Forms\Components\Textarea::make('value')
                ->label('Значение')
                ->rows(2),

            Forms\Components\Toggle::make('enabled')
                ->label('Включено'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')->label('Параметр'),
                Tables\Columns\TextColumn::make('value')->label('Значение')->limit(60),
                Tables\Columns\IconColumn::make('enabled')->boolean()->label('Включено'),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPaymentSettings::route('/'),
            'edit' => Pages\EditPaymentSetting::route('/{record}/edit'),
        ];
    }
}
