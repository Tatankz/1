<?php

namespace App\Filament\Resources\SocialBalanceResource\Pages;

use App\Filament\Resources\SocialBalanceResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditSocialBalance extends EditRecord
{
    protected static string $resource = SocialBalanceResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
