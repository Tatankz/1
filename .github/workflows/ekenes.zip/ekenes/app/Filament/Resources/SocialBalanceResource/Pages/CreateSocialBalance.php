<?php

namespace App\Filament\Resources\SocialBalanceResource\Pages;

use App\Filament\Resources\SocialBalanceResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSocialBalance extends CreateRecord
{
    protected static string $resource = SocialBalanceResource::class;
}
