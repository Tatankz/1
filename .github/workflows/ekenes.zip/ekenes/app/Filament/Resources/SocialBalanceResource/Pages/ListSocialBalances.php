<?php

namespace App\Filament\Resources\SocialBalanceResource\Pages;

use App\Filament\Resources\SocialBalanceResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListSocialBalances extends ListRecords
{
    protected static string $resource = SocialBalanceResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
