<?php

namespace App\Filament\Resources;

use App\Filament\Resources\CurrencyResource\Pages;
use App\Models\Currency;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Tables;
use Filament\Tables\Actions\DeleteAction;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables\Table;

class CurrencyResource extends Resource
{
    protected static ?string $model = Currency::class;

    protected static ?string $navigationIcon = 'heroicon-o-currency-dollar';

    protected static ?string $navigationLabel = 'Валюты';

    protected static ?string $pluralLabel = 'Валюты';

    protected static ?string $navigationGroup = 'Настройки';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('code')
                    ->label('Код')
                    ->required()
                    ->maxLength(3),
                Forms\Components\TextInput::make('symbol')
                    ->label('Символ')
                    ->required()
                    ->maxLength(5),
                Forms\Components\TextInput::make('name')
                    ->label('Название')
                    ->required()
                    ->maxLength(255),
                Forms\Components\Toggle::make('is_enabled')
                    ->label('Включена')
                    ->default(true),
                Forms\Components\Toggle::make('is_default')
                    ->label('По умолчанию')
                    ->default(false),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('code')->label('Code')->sortable()->searchable(),
                Tables\Columns\TextColumn::make('symbol')->label('Symbol')->sortable()->searchable(),
                Tables\Columns\TextColumn::make('name')->label('Name')->sortable()->searchable(),
                Tables\Columns\IconColumn::make('is_enabled')
                    ->boolean()
                    ->label('Включена'),
                Tables\Columns\IconColumn::make('is_default')
                    ->boolean()
                    ->label('По умолчанию'),
            ])
            ->actions([
                DeleteAction::make()
                    ->before(function (Currency $record) {
                        if ($record->is_default) {
                            $count = Currency::where('is_default', true)->count();
                            if ($count === 1) {
                                Notification::make()
                                    ->title('Ошибка')
                                    ->body('Нельзя удалить последнюю валюту по умолчанию.')
                                    ->danger()
                                    ->send();

                                throw new \Exception('Нельзя удалить последнюю валюту по умолчанию.');
                            }
                        }
                    }),
                Tables\Actions\EditAction::make()->label('Edit'),
            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListCurrencies::route('/'),
            'create' => Pages\CreateCurrency::route('/create'),
            'edit' => Pages\EditCurrency::route('/{record}/edit'),
        ];
    }
}
