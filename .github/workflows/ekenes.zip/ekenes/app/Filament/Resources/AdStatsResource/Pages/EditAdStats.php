<?php

namespace App\Filament\Resources\AdStatsResource\Pages;

use App\Filament\Resources\AdStatsResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditAdStats extends EditRecord
{
    protected static string $resource = AdStatsResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
