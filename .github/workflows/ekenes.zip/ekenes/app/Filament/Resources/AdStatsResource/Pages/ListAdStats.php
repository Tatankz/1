<?php

namespace App\Filament\Resources\AdStatsResource\Pages;

use App\Filament\Resources\AdStatsResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListAdStats extends ListRecords
{
    protected static string $resource = AdStatsResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
