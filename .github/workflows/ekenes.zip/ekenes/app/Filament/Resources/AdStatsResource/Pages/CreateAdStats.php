<?php

namespace App\Filament\Resources\AdStatsResource\Pages;

use App\Filament\Resources\AdStatsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAdStats extends CreateRecord
{
    protected static string $resource = AdStatsResource::class;
}
