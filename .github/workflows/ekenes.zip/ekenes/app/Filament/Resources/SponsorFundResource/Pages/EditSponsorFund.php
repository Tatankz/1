<?php

namespace App\Filament\Resources\SponsorFundResource\Pages;

use App\Filament\Resources\SponsorFundResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditSponsorFund extends EditRecord
{
    protected static string $resource = SponsorFundResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
