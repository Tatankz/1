<?php

namespace App\Filament\Resources\SponsorFundResource\Pages;

use App\Filament\Resources\SponsorFundResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListSponsorFunds extends ListRecords
{
    protected static string $resource = SponsorFundResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
