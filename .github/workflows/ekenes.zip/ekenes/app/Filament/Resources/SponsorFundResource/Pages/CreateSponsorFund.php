<?php

namespace App\Filament\Resources\SponsorFundResource\Pages;

use App\Filament\Resources\SponsorFundResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSponsorFund extends CreateRecord
{
    protected static string $resource = SponsorFundResource::class;
}
