<?php

namespace App\Http\Controllers\Payment;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CloudPaymentsController extends Controller
{
    public function pay(Request $request) {
        return response('CloudPayments pay (stub)', 200);
    }

    public function callback(Request $request) {
        return response('CloudPayments callback (stub)', 200);
    }
}
