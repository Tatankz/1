<?php

namespace App\Http\Controllers\Payment;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class RobokassaController extends Controller
{
    public function redirect(Request $request) {
        return response('Robokassa redirect (stub)', 200);
    }

    public function result(Request $request) {
        return response('Robokassa result (stub)', 200);
    }
}
