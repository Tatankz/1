<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Http\RedirectResponse;

class GoogleAuthController extends Controller
{
    /**
     * 🔐 Редирект на страницу авторизации Google
     */
    public function redirectToGoogle(): \Symfony\Component\HttpFoundation\RedirectResponse
    {
        // ✅ Запоминаем предыдущую страницу
        session(['previous_url' => url()->previous()]);

        return Socialite::driver('google')->redirect();
    }

    /**
     * 🔐 Обработка ответа от Google
     */
    public function handleGoogleCallback(): RedirectResponse
    {
        if (request()->has('error') && request()->get('error') === 'access_denied') {
            return redirect()->route('login')->with('error', 'Вы отменили вход через Google.');
        }

        try {
            $googleUser = Socialite::driver('google')->user();

            $user = User::updateOrCreate(
                [
                    'email' => $googleUser->getEmail(),
                ],
                [
                    'name' => $googleUser->getName() ?? $googleUser->getNickname() ?? 'Пользователь',
                    'email_verified_at' => now(),
                    'password' => Hash::make(Str::random(16)), // случайный пароль, если вход только через Google
                ]
            );

            Auth::login($user, true);

            // ✅ Возвращаем пользователя на страницу, с которой он пришёл
            return redirect(session()->pull('previous_url', '/dashboard'));

        } catch (\Exception $e) {
            return redirect('/login')->withErrors([
                'google_error' => 'Ошибка входа через Google: ' . $e->getMessage(),
            ]);
        }
    }
}
