<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class PhoneLoginController extends Controller
{
    public function showPhoneForm()
    {
        return view('auth.phone-login');
    }

    public function sendCode(Request $request)
    {
        $request->validate([
            'phone' => ['required', 'string', 'regex:/^\+7\d{10}$/'],
        ]);

        Log::info('[PhoneLogin] Получен номер: ' . $request->phone);

        return back()->with('success', 'Код отправлен (эмуляция)');
    }
}
