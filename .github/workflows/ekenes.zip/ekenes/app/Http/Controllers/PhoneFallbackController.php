<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use App\Models\User;

class PhoneFallbackController extends Controller
{
    public function showForm()
    {
        return view('auth.phone-login');
    }

    public function handle(Request $request)
    {
        $request->validate([
            'phone' => ['required', 'regex:/^\+77[0-9]{9}$/']
        ]);

        $phone = $request->input('phone');
        $code = rand(100000, 999999);

        Redis::setex('phone:code:' . $phone, 300, $code);
        session(['phone' => $phone]);

        // ✅ Mobizon: корректный текст SMS
        $text = "Код подтверждения eKenes.kz: {$code}";

        $response = Http::get("https://api.mobizon.kz/service/message/sendSmsMessage", [
            'recipient' => $phone,
            'text' => $text,
            'apiKey' => env('MOBIZON_API_KEY')
        ]);

        Log::info('[Mobizon] Ответ:', $response->json());

        return redirect()->route('phone.verify.form')->with('success', 'Код отправлен на ваш номер.');
    }

    public function verifyForm()
    {
        return view('auth.phone-verify');
    }

    public function verify(Request $request)
    {
        $request->validate([
            'phone' => ['required', 'regex:/^\+77[0-9]{9}$/'],
            'code' => ['required', 'digits:6']
        ]);

        $key = 'phone:code:' . $request->phone;
        $storedCode = Redis::get($key);

        if ($storedCode && $storedCode === $request->code) {
            Redis::del($key);

            $user = User::firstOrCreate(
                ['phone' => $request->phone],
                [
                    'name' => 'Пользователь',
                    'password' => bcrypt(Str::random(16)),
                    'email' => $request->phone . '@ekenes.kz' // 💡 Заполняем email, чтобы MySQL не ругался
                ]
            );

            Auth::login($user, true);
            return redirect('/dashboard');
        }

        return back()->withErrors(['code' => 'Неверный код подтверждения.']);
    }
}
