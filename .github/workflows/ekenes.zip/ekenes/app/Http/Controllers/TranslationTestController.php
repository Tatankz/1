<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class TranslationTestController extends Controller
{
    public function create()
    {
        $category = new Category();
        $category->setTranslation('name', 'ru', 'Юриспруденция');
        $category->setTranslation('name', 'kz', 'Заң');
        $category->setTranslation('name', 'en', 'Law');
        $category->save();

        return 'Категория создана с переводами';
    }

    public function show()
    {
        $category = Category::first();

        return response()->json([
            'ru' => $category->getTranslation('name', 'ru'),
            'kz' => $category->getTranslation('name', 'kz'),
            'en' => $category->getTranslation('name', 'en'),
        ]);
    }
}
