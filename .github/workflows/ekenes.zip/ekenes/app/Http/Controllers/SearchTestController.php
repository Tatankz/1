<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;

class SearchTestController extends Controller
{
    public function index(Request $request)
    {
        $query = $request->get('q', '');
        $results = [];

        if (!empty($query)) {
            $results = Order::search($query)->get();
        }

        return view('search-test.index', compact('query', 'results'));
    }
}
