<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\Str;
use App\Models\Page;

class PageController extends Controller
{
    public function show($slug)
    {
        $bladePath = "pages.$slug";

        if (View::exists($bladePath)) {
            return view($bladePath);
        }

        $page = Page::where('slug', $slug)->firstOrFail();

        return view('pages.dynamic', [
            'page' => $page
        ]);
    }
}
