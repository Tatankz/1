<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PhoneLoginRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'phone' => ['required', 'regex:/^\+7\d{10}$/']
        ];
    }

    public function messages(): array
    {
        return [
            'phone.required' => 'Номер телефона обязателен',
            'phone.regex' => 'Номер должен быть в формате +7XXXXXXXXXX'
        ];
    }
}
