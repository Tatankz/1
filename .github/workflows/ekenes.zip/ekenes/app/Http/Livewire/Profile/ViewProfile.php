<?php

namespace App\Http\Livewire\Profile;

use Livewire\Component;
use App\Models\Profile;
use Illuminate\Support\Facades\Auth;

class ViewProfile extends Component
{
    public $profile;

    public function mount($userId = null)
    {
        // Если не передали userId, берем профиль текущего пользователя
        $targetUserId = $userId ?: Auth::id();

        $this->profile = Profile::where('user_id', $targetUserId)->first();
    }

    public function render()
    {
        return view('livewire.profile.view-profile');
    }
}
