<?php

namespace App\Http\Livewire\Profile;

use Livewire\Component;
use Livewire\WithFileUploads;
use App\Models\Profile;
use Illuminate\Support\Facades\Auth;

class EditProfile extends Component
{
    use WithFileUploads;

    public $photo;          // Для хранения загружаемого файла
    public $bio;
    public $specialization;
    public $location;
    public $phone;

    // Текущее фото (URL) — чтобы отображать в форме
    public $currentPhotoUrl;

    public function mount()
    {
        $profile = Profile::where('user_id', Auth::id())->first();

        if ($profile) {
            // Если уже есть загруженное фото через MediaLibrary — получаем его URL
            $media = $profile->getFirstMedia('photos');
            $this->currentPhotoUrl  = $media ? $media->getUrl() : null;

            $this->bio             = $profile->bio;
            $this->specialization  = $profile->specialization;
            $this->location        = $profile->location;
            $this->phone           = $profile->phone;
        }
    }

    public function updateProfile()
    {
        // Валидация входных данных
        $this->validate([
            'photo' => 'nullable|image|max:2048', // 2 MB
        ]);

        $profile = Profile::updateOrCreate(
            ['user_id' => Auth::id()],
            [
                'bio'            => $this->bio,
                'specialization' => $this->specialization,
                'location'       => $this->location,
                'phone'          => $this->phone,
            ]
        );

        // Если пользователь загрузил новое фото
        if ($this->photo) {
            // Очищаем предыдущий файл (singleFile() сам управляет, но на всякий случай)
            $profile->clearMediaCollection('photos');

            // Добавляем новое медиа в коллекцию
            $profile->addMedia($this->photo->getRealPath())->toMediaCollection('photos');
        }

        session()->flash('message', 'Профиль обновлён!');
    }

    public function render()
    {
        return view('livewire.profile.edit-profile');
    }
}
