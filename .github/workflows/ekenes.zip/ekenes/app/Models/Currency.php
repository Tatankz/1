<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Filament\Notifications\Notification;

class Currency extends Model
{
    protected $fillable = [
        'code',
        'symbol',
        'name',
        'is_enabled',
        'is_default',
    ];

    public static function boot()
    {
        parent::boot();

        // 🔐 Блокировка удаления последней валюты по умолчанию
        static::deleting(function ($currency) {
            if ($currency->is_default) {
                $count = static::where('is_default', true)->count();

                if ($count === 1) {
                    // ⚠️ Показываем уведомление через Filament UI
                    Notification::make()
                        ->title('Ошибка')
                        ->body('Нельзя удалить последнюю валюту по умолчанию.')
                        ->danger()
                        ->send();

                    // ⛔ Прерываем удаление
                    abort(403, 'Нельзя удалить последнюю валюту по умолчанию.');
                }
            }
        });
    }
}
