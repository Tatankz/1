<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    //
}
