<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Laravel\Scout\Searchable;
use Spatie\Translatable\HasTranslations;

class Subcategory extends Model
{
    use Searchable;
    use HasFactory, HasTranslations;

    protected $fillable = ['name', 'category_id'];
    public $translatable = ['name'];
}
