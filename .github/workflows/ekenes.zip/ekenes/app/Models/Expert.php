<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Laravel\Scout\Searchable;

class Expert extends Model
{
    use Searchable;

    protected $fillable = ['name', 'bio'];

    public function toSearchableArray(): array
    {
        return [
            'name' => $this->name,
            'bio' => $this->bio,
        ];
    }
}
