<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Laravel\Scout\Searchable;

class Offer extends Model
{
    use HasFactory, Searchable;

    protected $fillable = ['order_id', 'user_id', 'price', 'message', 'status'];

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function toSearchableArray(): array
    {
        return [
            'message' => $this->message,
            'status' => $this->status,
        ];
    }
}
