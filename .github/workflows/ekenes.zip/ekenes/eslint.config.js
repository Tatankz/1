// eslint.config.js (в корне проекта)
import vue from 'eslint-plugin-vue';

export default [
  {
    files: ['resources/js/**/*.vue', 'resources/js/**/*.js'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'module'
    },
    plugins: {
      vue
    },
    rules: {
      'vue/multi-word-component-names': 'off'
    }
  }
];
