#!/bin/bash

# ✅ 1. Устанавливаем Node.js и npm (если ещё не установлены)
apt update
apt install -y nodejs npm

# ✅ 2. Устанавливаем cloudcmd глобально
npm install -g cloudcmd

# ✅ 3. Создаём systemd unit
cat <<EOF > /etc/systemd/system/cloudcmd.service
[Unit]
Description=Cloud Commander
After=network.target

[Service]
ExecStart=/usr/bin/env cloudcmd --auth --username=tatan --password='Ehfkmcr2025!' --root=/var/www/ekenes --port=8000
Restart=always
User=www-data
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

# ✅ 4. Перезапускаем systemd и включаем автозапуск
systemctl daemon-reexec
systemctl daemon-reload
systemctl enable cloudcmd.service
systemctl start cloudcmd.service

# ✅ 5. Создаём nginx-конфиг
cat <<EOF > /etc/nginx/sites-available/cloudcmd
server {
    listen 80;
    server_name files.ekenes.kz;
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl;
    server_name files.ekenes.kz;

    ssl_certificate /etc/letsencrypt/live/files.ekenes.kz/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/files.ekenes.kz/privkey.pem;

    location / {
        proxy_pass http://localhost:8000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

# ✅ 6. Подключаем сайт и проверяем конфигурацию
ln -sf /etc/nginx/sites-available/cloudcmd /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

# ✅ 7. Получаем SSL-сертификат через certbot
certbot --nginx -d files.ekenes.kz
